
  # Redesign Content Management Interface

  This is a code bundle for Redesign Content Management Interface. The original project is available at https://www.figma.com/design/8J8nTb8543S5t3F1FXbW9X/Redesign-Content-Management-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  